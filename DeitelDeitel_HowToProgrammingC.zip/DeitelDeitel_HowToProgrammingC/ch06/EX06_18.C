/* ex06_18.c */
#include <stdio.h>
#define SIZE 10

void someFunction( const int [], int );

int main()
{
   int a[ SIZE ] = { 8, 3, 1, 2, 6, 0, 9, 7, 4, 5 };

   printf( "Answer is:\n" );
   someFunction( a, SIZE );
   printf( "\n" );
   return 0;
}

void someFunction( const int b[], int size )
{
   if ( size > 0 ) {
      someFunction( &b[ 1 ], size - 1 );
      printf( "%d  ", b[ 0 ] );
   }
}


/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
