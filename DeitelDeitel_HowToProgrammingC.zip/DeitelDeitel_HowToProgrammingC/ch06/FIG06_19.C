/* Fig. 6.19: fig06_19.c
   Binary search of an array */
#include <stdio.h>
#define SIZE 15

int binarySearch( const int [], int, int, int );
void printHeader( void );
void printRow( const int [], int, int, int );

int main()
{
   int a[ SIZE ], i, key, result;

   for ( i = 0; i <= SIZE - 1; i++ )
      a[ i ] = 2 * i;

   printf( "Enter a number between 0 and 28: " );
   scanf( "%d", &key );

   printHeader();
   result = binarySearch( a, key, 0, SIZE - 1 );

   if ( result != -1 )
      printf( "\n%d found in array element %d\n", 
              key, result );
   else
      printf( "\n%d not found\n", key );

   return 0;
}

int binarySearch( const int b[], int searchKey, 
                  int low, int high )
{
   int middle;

   while ( low <= high ) {
      middle = ( low + high ) / 2;

      printRow( b, low, middle, high );

      if ( searchKey == b[ middle ] )
         return middle;
      else if ( searchKey < b[ middle ] )
         high = middle - 1;
      else
         low = middle + 1;
   }

   return -1;   /* searchKey not found */
}

/* Print a header for the output */
void printHeader( void )
{
   int i;

   printf( "\nSubscripts:\n" );

   for ( i = 0; i <= SIZE - 1; i++ )
      printf( "%3d ", i );

   printf( "\n" );

   for ( i = 1; i <= 4 * SIZE; i++ )
      printf( "-" );

   printf( "\n" );
}

/* Print one row of output showing the current
   part of the array being processed. */
void printRow( const int b[], int low, int mid, int high )
{
   int i;

   for ( i = 0; i <= SIZE - 1; i++ )
      if ( i < low || i > high )
         printf( "    " );
      else if ( i == mid )
         printf( "%3d*", b[ i ] );  /* mark middle value */
      else
         printf( "%3d ", b[ i ] );

   printf( "\n" );
}




/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
