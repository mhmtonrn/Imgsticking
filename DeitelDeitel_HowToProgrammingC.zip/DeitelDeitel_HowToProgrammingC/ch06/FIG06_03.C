/* Fig. 6.3: fig06_03.c
   initializing an array */
#include <stdio.h>

int main()
{
   int n[ 10 ], i;
   
   for ( i = 0; i <= 9; i++ )       /* initialize array */
      n[ i ] = 0;

   printf( "%s%13s\n", "Element", "Value" );
   for ( i = 0; i <= 9; i++ )        /* print array */
      printf( "%7d%13d\n", i, n[ i ] );

   return 0;
}



/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
