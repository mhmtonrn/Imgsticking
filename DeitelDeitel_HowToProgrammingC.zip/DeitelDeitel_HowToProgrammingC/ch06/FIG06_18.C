/* Fig. 6.18: fig06_18.c
   Linear search of an array */
#include <stdio.h>
#define SIZE 100

int linearSearch( const int [], int, int );

int main()
{   
   int a[ SIZE ], x, searchKey, element;

   for ( x = 0; x <= SIZE - 1; x++ )  /* create data */
      a[ x ] = 2 * x;

   printf( "Enter integer search key:\n" );
   scanf( "%d", &searchKey );
   element = linearSearch( a, searchKey, SIZE );

   if ( element != -1 )
      printf( "Found value in element %d\n", element );
   else
      printf( "Value not found\n" );

   return 0;
}

int linearSearch( const int array[], int key, int size )
{
   int n;

   for ( n = 0; n <= size - 1; ++n )
      if ( array[ n ] == key )
         return n;

   return -1;
}



/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
