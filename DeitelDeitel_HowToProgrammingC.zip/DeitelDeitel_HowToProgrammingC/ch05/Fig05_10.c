/* Fig. 5.10: fig05_10.c
   Craps */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int rollDice( void );

int main()
{ 
   int gameStatus, sum, myPoint;

   srand( time( NULL ) );
   sum = rollDice(  );          /* first roll of the dice */

   switch( sum ) {
      case 7: case 11:          /* win on first roll */
         gameStatus = 1;
         break;
      case 2: case 3: case 12:  /* lose on first roll */
         gameStatus = 2;
         break;
      default:                  /* remember point */
         gameStatus = 0;
         myPoint = sum;
         printf( "Point is %d\n", myPoint );
         break;
   }

   while ( gameStatus == 0 ) {    /* keep rolling */
      sum = rollDice(  );

      if ( sum == myPoint )       /* win by making point */
         gameStatus = 1;
      else
         if ( sum == 7 )          /* lose by rolling 7 */
            gameStatus = 2;
   }

   if ( gameStatus == 1 )
      printf( "Player wins\n" );
   else
      printf( "Player loses\n" );

   return 0;
}

int rollDice( void )
{
   int die1, die2, workSum;

   die1 = 1 + ( rand() % 6 );
   die2 = 1 + ( rand() % 6 );
   workSum = die1 + die2;
   printf( "Player rolled %d + %d = %d\n", die1, die2, workSum );
   return workSum;
}



/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
