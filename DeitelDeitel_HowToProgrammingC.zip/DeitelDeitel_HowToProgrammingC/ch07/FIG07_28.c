/* Fig. 7.28: fig07_28.cpp
   Demonstrating an array of pointers to functions */
#include <stdio.h>
void function1( int );
void function2( int );
void function3( int );

int main()
{
   void (*f[ 3 ])( int ) = { function1, function2, function3 };
   int choice;

   printf( "Enter a number between 0 and 2, 3 to end: " );
   scanf( "%d", &choice );

   while ( choice >= 0 && choice < 3 ) {
      (*f[ choice ])( choice );
      printf( "Enter a number between 0 and 2, 3 to end: ");
      scanf( "%d", &choice );
   }

   printf( "Program execution completed.\n" );

   return 0;
}

void function1( int a )
{
   printf( "You entered %d"  
           " so function1 was called\n\n", a );
}

void function2( int b )
{
   printf( "You entered %d"  
           " so function2 was called\n\n", b );
}

void function3( int c )
{
   printf( "You entered %d"  
           " so function3 was called\n\n", c );
}



/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
