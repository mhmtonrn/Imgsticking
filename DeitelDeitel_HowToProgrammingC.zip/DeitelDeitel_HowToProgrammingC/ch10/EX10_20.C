/* ex10_20.c */
#include <stdio.h>

int mystery( unsigned );

int main()
{ 
   unsigned x;

   printf( "Enter an integer: " );
   scanf( "%u", &x );
   printf( "The result is %d\n", mystery( x ) );
   return 0;
}

int mystery( unsigned bits )
{ 
   unsigned i, mask = 1 << 31, total = 0;

   for ( i = 1; i <= 32; i++, bits <<= 1 )
      if ( ( bits & mask ) == mask ) 
         ++total;

    return !( total % 2 ) ? 1 : 0;
}

 

/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
