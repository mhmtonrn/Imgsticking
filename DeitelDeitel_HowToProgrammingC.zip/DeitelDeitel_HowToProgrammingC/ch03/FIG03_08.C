/* Fig. 3.8: fig03_08.c
   Class average program with 
   sentinel-controlled repetition */
#include <stdio.h>

int main()
{
   float average;              /* new data type */
   int counter, grade, total;
   
   /* initialization phase */
   total = 0;
   counter = 0;
   
   /* processing phase */
   printf( "Enter grade, -1 to end: " );
   scanf( "%d", &grade );
   
   while ( grade != -1 ) {
      total = total + grade;
      counter = counter + 1; 
      printf( "Enter grade, -1 to end: " );
      scanf("%d", &grade);
   }

   /* termination phase */
   if ( counter != 0 ) {
      average = ( float ) total / counter;
      printf( "Class average is %.2f", average );
   }
   else
      printf( "No grades were entered\n" );

   return 0;   /* indicate program ended successfully */
}



/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
