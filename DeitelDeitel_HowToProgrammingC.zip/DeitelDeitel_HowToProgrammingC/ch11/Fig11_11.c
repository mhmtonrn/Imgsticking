/* Fig. 11.11: fig11_11.c
   Creating a randomly accessed file sequentially */
#include <stdio.h>

struct clientData { 
   int acctNum;
   char lastName[ 15 ];
   char firstName[ 10 ];
   double balance;
};

int main()
{ 
   int i;
   struct clientData blankClient = { 0, "", "", 0.0 };
   FILE *cfPtr;
 
   if ( ( cfPtr = fopen( "credit.dat", "w" ) ) == NULL )
      printf( "File could not be opened.\n" );
   else { 

      for ( i = 1; i <= 100; i++ )
         fwrite( &blankClient, 
                sizeof( struct clientData ), 1, cfPtr );

      fclose ( cfPtr );
   }

   return 0;
}


/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
