/* Fig. 11.12: fig11_12.c
   Writing to a random access file */
#include <stdio.h>

struct clientData { 
   int acctNum;
   char lastName[ 15 ];
   char firstName[ 10 ];
   double balance;
};
 
int main() 
{ 
   FILE *cfPtr;
   struct clientData client = { 0, "", "", 0.0 };

   if ( ( cfPtr = fopen( "credit.dat", "r+" ) ) == NULL )
      printf( "File could not be opened.\n" );
   else { 
      printf( "Enter account number"
             " ( 1 to 100, 0 to end input )\n? " );
      scanf( "%d", &client.acctNum );

      while ( client.acctNum != 0 ) { 
         printf( "Enter lastname, firstname, balance\n? " );
         fscanf( stdin, "%s%s%lf", client.lastName, 
                client.firstName, &client.balance );
         fseek( cfPtr, ( client.acctNum - 1 ) * 
                sizeof( struct clientData ), SEEK_SET );
         fwrite( &client, sizeof( struct clientData ), 1, 
                 cfPtr );
         printf( "Enter account number\n? " );
         scanf( "%d", &client.acctNum );
      }

      fclose( cfPtr );
   } 

   return 0;
}
 


/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
