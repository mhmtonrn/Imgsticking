/* Fig. 8.13: fig08_13.c
   Using gets and putchar */
#include <stdio.h>

int main()
{  
   char sentence[ 80 ];
   void reverse( const char * const );
   
   printf( "Enter a line of text:\n" );
   gets( sentence );

   printf( "\nThe line printed backwards is:\n" );
   reverse( sentence );

   return 0;
}

void reverse( const char * const sPtr )
{  
   if ( sPtr[ 0 ] == '\0' )
      return;
   else {  
      reverse( &sPtr[ 1 ] );
      putchar( sPtr[ 0 ] );
   }
}



/**************************************************************************
 * (C) Copyright 2000 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
